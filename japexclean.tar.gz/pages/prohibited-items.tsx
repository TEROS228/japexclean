import Footer from '../components/Footer';

export default function ProhibitedItems() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12 flex-1">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">🚫 Prohibited & Restricted Items (EMS Japan Post)</h1>
        <p className="text-gray-600 mb-8">
          Before requesting international shipping, please make sure your package does not contain any prohibited or restricted items. Japan Post and customs strictly control what can be exported.
        </p>

        <div className="prose prose-lg max-w-none space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">❌ Completely Prohibited Items</h2>
            <p className="text-gray-700 mb-4">
              These items cannot be shipped by EMS under any circumstances:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>💣 Explosives, gunpowder, fireworks</li>
              <li>🔫 Firearms, weapons, airsoft guns, parts of weapons</li>
              <li>💊 Narcotics, illegal drugs, CBD products</li>
              <li>🍷 Alcoholic beverages over 24%</li>
              <li>💨 Vapes, e-cigarettes, or liquid nicotine</li>
              <li>🪫 Lithium batteries (loose or built-in without proper protection)</li>
              <li>💉 Medicines requiring a prescription in Japan</li>
              <li>💵 Cash, coins, or gift cards</li>
              <li>🐾 Live animals, insects, plants, seeds</li>
              <li>🔥 Flammable liquids or gases (perfume, sprays, paint, lighter fluid)</li>
              <li>☣️ Chemical materials, poison, acids, toxic substances</li>
            </ul>
            <p className="text-yellow-600 font-semibold mt-4">
              ⚠️ If your package includes a prohibited item, it will be held at our warehouse until you choose to return or dispose of it (¥600 disposal fee applies).
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">⚠️ Restricted Items (Possible, but with Conditions)</h2>
            <p className="text-gray-700 mb-4">
              These items may be shipped if they meet Japan Post and destination country regulations:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>🔋 Devices containing built-in lithium batteries (phones, laptops, cameras) — only if battery capacity ≤ 100 Wh and device is turned off.</li>
              <li>🍫 Food, snacks, tea, vitamins — allowed if factory-sealed, non-perishable, and small in quantity.</li>
              <li>👕 Clothing, shoes, accessories — generally allowed.</li>
              <li>🎮 Game consoles — allowed, but without extra battery packs.</li>
              <li>💄 Cosmetics — allowed if volume per bottle ≤ 100 ml and non-flammable.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">📦 Our Policy</h2>
            <p className="text-gray-700 mb-4">
              Japrix strictly follows Japan Post regulations. If a package contains prohibited or dangerous goods, we cannot send it internationally. You will be able to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>♻️ Dispose of the item</li>
              <li>🔁 Return it to the seller (if they accept returns)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Contact Information</h2>
            <p className="text-gray-700">
              If you need to check whether a specific item can be shipped before ordering:<br />
              📧 <a href="mailto:first5500@gmail.com" className="text-blue-600 hover:underline">first5500@gmail.com</a><br />
              <strong>Subject:</strong> Item check before order
            </p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
