import { NextApiRequest, NextApiResponse } from 'next';

// Простой кэш для результатов
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 минут

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { query } = req.query;

  if (!query || typeof query !== 'string' || query.length < 3) {
    return res.status(400).json({ error: 'Query must be at least 3 characters' });
  }

  // Проверяем кэш
  const cached = cache.get(query);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return res.status(200).json(cached.data);
  }

  try {
    // Список поддерживаемых стран
    const countryCodes = 'us,ca,de,fr,gb,it,es,nl,th,tw,kr,cn,ph,id,vn,my,in,br,ar,za';

    // Используем Nominatim API для поиска адресов
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 секунд таймаут

    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?` +
      `q=${encodeURIComponent(query)}&` +
      `format=json&` +
      `addressdetails=1&` +
      `limit=5&` +
      `countrycodes=${countryCodes}`,
      {
        headers: {
          'User-Agent': 'JapanExpress/1.0',
          'Accept-Language': 'en'
        },
        signal: controller.signal
      }
    );

    clearTimeout(timeoutId);

    if (!response.ok) {
      console.error('Nominatim API error:', response.status);
      return res.status(200).json({ suggestions: [] });
    }

    const data = await response.json();

    // Проверяем что data это массив
    if (!Array.isArray(data)) {
      console.error('Unexpected API response format');
      return res.status(200).json({ suggestions: [] });
    }

    // Форматируем результаты
    const suggestions = data.map((item: any) => ({
      display_name: item.display_name,
      address: {
        road: item.address.road || '',
        house_number: item.address.house_number || '',
        city: item.address.city || item.address.town || item.address.village || '',
        state: item.address.state || '',
        postcode: item.address.postcode || '',
        country: item.address.country || ''
      },
      lat: item.lat,
      lon: item.lon
    }));

    const result = { suggestions };

    // Сохраняем в кэш
    cache.set(query, { data: result, timestamp: Date.now() });

    // Очищаем старые записи из кэша (простая чистка)
    if (cache.size > 100) {
      const oldestKey = cache.keys().next().value;
      if (oldestKey) {
        cache.delete(oldestKey);
      }
    }

    res.status(200).json(result);

  } catch (error: any) {
    // Обрабатываем таймаут
    if (error.name === 'AbortError') {
      console.error('Address search timeout');
      return res.status(200).json({ suggestions: [] });
    }

    console.error('Address autocomplete error:', error.message);
    res.status(200).json({ suggestions: [] });
  }
}
