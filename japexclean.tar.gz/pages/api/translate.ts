import type { NextApiRequest, NextApiResponse } from 'next';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const AZURE_TRANSLATOR_KEY = process.env.AZURE_TRANSLATOR_KEY || '';
const AZURE_TRANSLATOR_REGION = process.env.AZURE_TRANSLATOR_REGION || 'japaneast';
const AZURE_TRANSLATOR_ENDPOINT = process.env.AZURE_TRANSLATOR_ENDPOINT || 'https://api.cognitive.microsofttranslator.com';

// Функция для исправления слипшихся слов
function fixConcatenatedWords(text: string): string {
  // Список частых паттернов, где слова слипаются
  const patterns = [
    // Знаки валюты и числа со словами
    { regex: /([¥$€£₽])(\d+)([a-zA-Z])/g, replacement: '$1$2 $3' }, // ¥900if -> ¥900 if
    { regex: /([a-z])([¥$€£₽]\d)/g, replacement: '$1 $2' }, // pay¥900 -> pay ¥900
    { regex: /(\d)([a-zA-Z]{2,})/g, replacement: '$1 $2' }, // 900if -> 900 if

    // Артикли и предлоги
    { regex: /([a-z])([A-Z])/g, replacement: '$1 $2' }, // camelCase -> camel Case
    { regex: /(\d)([A-Z][a-z])/g, replacement: '$1 $2' }, // 3Day -> 3 Day
    { regex: /([a-z])(\d)/g, replacement: '$1 $2' }, // day3 -> day 3

    // Частые английские слова, которые слипаются
    { regex: /([a-z])(The|And|For|With|From|Into|Over|Under|About|After|Before|If|Or|But)/g, replacement: '$1 $2' },
    { regex: /(The|And|For|With|From|Into|Over|Under|About|After|Before|If|Or|But)([A-Z][a-z])/g, replacement: '$1 $2' },

    // Предлоги в конце слов
    { regex: /([a-z])(In|On|At|To|Of|By)([A-Z])/g, replacement: '$1 $2 $3' },

    // Двойные пробелы убираем
    { regex: /\s{2,}/g, replacement: ' ' },
  ];

  let result = text;
  for (const pattern of patterns) {
    result = result.replace(pattern.regex, pattern.replacement);
  }

  return result.trim();
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { texts, fromLang, toLang } = req.body;

  if (!texts || !Array.isArray(texts) || !fromLang || !toLang) {
    return res.status(400).json({ error: 'Invalid request' });
  }

  if (fromLang === toLang) {
    return res.json({ translations: texts });
  }

  try {
    const translations: string[] = [];
    const textsToTranslate: string[] = [];
    const indexMap: number[] = [];

    // Проверяем кэш для каждого текста
    for (let i = 0; i < texts.length; i++) {
      const text = texts[i];

      const cached = await prisma.translationCache.findUnique({
        where: {
          sourceText_sourceLang_targetLang: {
            sourceText: text,
            sourceLang: fromLang,
            targetLang: toLang,
          },
        },
      });

      if (cached) {
        translations[i] = cached.translation;
      } else {
        textsToTranslate.push(text);
        indexMap.push(i);
      }
    }

    // Переводим только тексты, которых нет в кэше
    if (textsToTranslate.length > 0) {
      const response = await fetch(
        `${AZURE_TRANSLATOR_ENDPOINT}/translate?api-version=3.0&from=${fromLang}&to=${toLang}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Ocp-Apim-Subscription-Key': AZURE_TRANSLATOR_KEY,
            'Ocp-Apim-Subscription-Region': AZURE_TRANSLATOR_REGION,
          },
          body: JSON.stringify(textsToTranslate.map(text => ({ text }))),
        }
      );

      if (!response.ok) {
        console.error('Translation API error:', response.status, response.statusText);
        // Возвращаем оригинальные тексты для непереведенных
        for (let i = 0; i < textsToTranslate.length; i++) {
          translations[indexMap[i]] = textsToTranslate[i];
        }
      } else {
        const responseText = await response.text();

        if (!responseText || responseText.trim() === '') {
          console.error('Empty response from translation API');
          // Возвращаем оригинальные тексты
          for (let i = 0; i < textsToTranslate.length; i++) {
            translations[indexMap[i]] = textsToTranslate[i];
          }
        } else {
          try {
            const data = JSON.parse(responseText);

            if (Array.isArray(data)) {
              // Сохраняем новые переводы в кэш и результаты
              for (let i = 0; i < data.length; i++) {
                let translatedText = data[i]?.translations?.[0]?.text || textsToTranslate[i];

                // Исправляем слипшиеся слова
                translatedText = fixConcatenatedWords(translatedText);

                const originalIndex = indexMap[i];

                translations[originalIndex] = translatedText;

                // Сохраняем в кэш
                try {
                  await prisma.translationCache.upsert({
                    where: {
                      sourceText_sourceLang_targetLang: {
                        sourceText: textsToTranslate[i],
                        sourceLang: fromLang,
                        targetLang: toLang,
                      },
                    },
                    update: {
                      translation: translatedText,
                    },
                    create: {
                      sourceText: textsToTranslate[i],
                      sourceLang: fromLang,
                      targetLang: toLang,
                      translation: translatedText,
                    },
                  });
                } catch (cacheError) {
                  console.error('Cache error:', cacheError);
                  // Продолжаем даже если кэш не сработал
                }
              }
            }
          } catch (jsonError) {
            console.error('JSON parse error:', jsonError, 'Response:', responseText);
            // Возвращаем оригинальные тексты
            for (let i = 0; i < textsToTranslate.length; i++) {
              translations[indexMap[i]] = textsToTranslate[i];
            }
          }
        }
      }
    }

    return res.json({ translations });
  } catch (error) {
    console.error('Translation error:', error);
    return res.status(500).json({ error: 'Translation failed', translations: texts });
  }
}
