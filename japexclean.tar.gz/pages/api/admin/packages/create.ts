import { NextApiRequest, NextApiResponse } from 'next';
import { verifyToken } from '../../../../lib/jwt';
import { prisma } from '../../../../lib/prisma';
import formidable from 'formidable';
import fs from 'fs';
import path from 'path';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: 'Token required' });
  }

  const user = verifyToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  try {
    // Находим пользователя в БД
    const dbUser = await prisma.user.findUnique({
      where: { email: user.email }
    });

    if (!dbUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Проверяем, что пользователь админ
    if (!dbUser.isAdmin) {
      return res.status(403).json({ error: 'Access denied: Admin only' });
    }

    // Парсим форму с файлами
    const uploadDir = path.join(process.cwd(), 'public', 'uploads', 'packages');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }

    const form = formidable({
      uploadDir,
      keepExtensions: true,
      maxFileSize: 10 * 1024 * 1024, // 10MB
    });

    const [fields, files] = await new Promise<[formidable.Fields, formidable.Files]>((resolve, reject) => {
      form.parse(req, (err, fields, files) => {
        if (err) reject(err);
        else resolve([fields, files]);
      });
    });

    const orderItemId = Array.isArray(fields.orderItemId) ? fields.orderItemId[0] : fields.orderItemId;
    const trackingNumber = Array.isArray(fields.trackingNumber) ? fields.trackingNumber[0] : fields.trackingNumber;
    const weight = Array.isArray(fields.weight) ? fields.weight[0] : fields.weight;
    const shippingCost = Array.isArray(fields.shippingCost) ? fields.shippingCost[0] : fields.shippingCost;
    const notes = Array.isArray(fields.notes) ? fields.notes[0] : fields.notes;
    const shippingMethod = Array.isArray(fields.shippingMethod) ? fields.shippingMethod[0] : fields.shippingMethod;

    if (!orderItemId) {
      return res.status(400).json({ error: 'Order Item ID required' });
    }

    // Проверяем, что товар заказа существует
    const orderItem = await prisma.orderItem.findUnique({
      where: { id: orderItemId },
      include: {
        order: {
          include: { user: true }
        },
        package: true
      }
    });

    if (!orderItem) {
      return res.status(404).json({ error: 'Order item not found' });
    }

    // Проверяем, что для этого товара еще не создана посылка
    if (orderItem.package) {
      return res.status(400).json({ error: 'Package already exists for this item' });
    }

    // Обрабатываем загруженное фото
    let packagePhotoUrl = null;
    if (files.packagePhoto) {
      const photoFile = Array.isArray(files.packagePhoto) ? files.packagePhoto[0] : files.packagePhoto;
      const filename = path.basename(photoFile.filepath);
      packagePhotoUrl = `/uploads/packages/${filename}`;
    }

    // Создаем посылку
    const packageRecord = await prisma.package.create({
      data: {
        userId: orderItem.order.userId,
        orderItemId: orderItemId,
        trackingNumber: trackingNumber || null,
        weight: weight ? parseFloat(weight) : null,
        shippingCost: shippingCost ? parseInt(shippingCost) : 0,
        notes: notes || null,
        shippingMethod: shippingMethod || 'ems',
        packagePhoto: packagePhotoUrl,
        status: 'ready'
      }
    });

    // Создаем уведомление для пользователя
    await prisma.notification.create({
      data: {
        userId: orderItem.order.userId,
        type: 'package_ready',
        title: 'Посылка готова к отправке',
        message: `Ваш товар "${orderItem.title}" прибыл на склад и готов к отправке.${trackingNumber ? ` Трек-номер: ${trackingNumber}` : ''}`,
        read: false
      }
    });

    res.status(200).json({
      success: true,
      package: packageRecord
    });

  } catch (error) {
    console.error('Error creating package:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}
