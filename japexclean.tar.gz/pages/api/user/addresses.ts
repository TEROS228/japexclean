import { NextApiRequest, NextApiResponse } from 'next';
import { verifyToken } from '../../../lib/jwt';
import { prisma } from '../../../lib/prisma';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Отключаем кеширование
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  const token = req.headers.authorization?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ error: 'Token required' });
  }

  const user = verifyToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  try {
    // Находим пользователя в БД
    const dbUser = await prisma.user.findUnique({
      where: { email: user.email }
    });

    if (!dbUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (req.method === 'GET') {
      // Получаем адреса из БД
      const addresses = await prisma.address.findMany({
        where: { userId: dbUser.id },
        orderBy: { createdAt: 'desc' }
      });

      res.status(200).json({ addresses, hasAddress: addresses.length > 0 });
    } else if (req.method === 'POST') {
      // Создаем новый адрес
      const { name, address, apartment, city, state, postalCode, country, phoneNumber, ssnNumber, taxIdType, taxIdNumber, companyName } = req.body;

      // Удаляем старый адрес если есть (у каждого пользователя только 1 адрес)
      await prisma.address.deleteMany({
        where: { userId: dbUser.id }
      });

      // Создаем новый
      const newAddress = await prisma.address.create({
        data: {
          userId: dbUser.id,
          name,
          address,
          apartment,
          city,
          state,
          postalCode,
          country,
          phoneNumber,
          ssnNumber: ssnNumber || null,
          taxIdType: taxIdType || null,
          taxIdNumber: taxIdNumber || null,
          companyName: companyName || null
        }
      });

      res.status(200).json({ address: newAddress });
    } else if (req.method === 'DELETE') {
      // Удаляем адрес
      const { id } = req.body;

      await prisma.address.delete({
        where: {
          id,
          userId: dbUser.id
        }
      });

      res.status(200).json({ success: true });
    } else {
      return res.status(405).json({ error: 'Method not allowed' });
    }

  } catch (error) {
    console.error('Error handling address:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}
