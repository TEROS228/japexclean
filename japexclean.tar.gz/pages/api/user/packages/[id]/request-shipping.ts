import { NextApiRequest, NextApiResponse } from 'next';
import { verifyToken } from '../../../../../lib/jwt';
import { prisma } from '../../../../../lib/prisma';
import { sendTelegramNotification } from '../../../../../lib/telegram';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Отключаем кеширование
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const token = req.headers.authorization?.replace('Bearer ', '');
  const { id } = req.query;

  if (!token) {
    return res.status(401).json({ error: 'Token required' });
  }

  const user = verifyToken(token);
  if (!user) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  try {
    const dbUser = await prisma.user.findUnique({
      where: { email: user.email }
    });

    if (!dbUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Получаем адрес пользователя
    const userAddress = await prisma.address.findFirst({
      where: { userId: dbUser.id }
    });

    if (!userAddress) {
      return res.status(400).json({ error: 'Please add a shipping address first' });
    }

    // Получаем посылку
    console.log('Looking for package with id:', id, 'for user:', dbUser.id);

    const pkg = await prisma.package.findUnique({
      where: {
        id: id as string,
        userId: dbUser.id
      },
      include: {
        orderItem: true
      }
    });

    if (!pkg) {
      console.log('Package not found');
      return res.status(404).json({ error: 'Package not found' });
    }

    console.log('Package found:', pkg.id, 'shippingCost:', pkg.shippingCost, 'status:', pkg.status);

    // Проверяем что посылка готова к отправке
    if (pkg.status !== 'ready') {
      return res.status(400).json({ error: 'Package is not ready for shipping' });
    }

    // Проверяем что нет активных сервисов в обработке
    if (pkg.photoService && pkg.photoServiceStatus === 'pending') {
      return res.status(400).json({ error: 'Photo service is still processing. Please wait.' });
    }

    if (pkg.consolidation) {
      return res.status(400).json({ error: 'Package consolidation is in progress. Please wait.' });
    }

    // Проверяем баланс для оплаты доставки
    if (dbUser.balance < pkg.shippingCost) {
      return res.status(400).json({ error: 'Insufficient balance for shipping' });
    }

    // Списываем стоимость доставки
    await prisma.user.update({
      where: { id: dbUser.id },
      data: { balance: { decrement: pkg.shippingCost } }
    });

    // Создаем транзакцию
    await prisma.transaction.create({
      data: {
        userId: dbUser.id,
        amount: -pkg.shippingCost,
        type: 'shipping',
        status: 'completed',
        description: `Shipping cost for "${pkg.orderItem.title}"`
      }
    });

    // Обновляем статус посылки и привязываем адрес доставки
    const updatedPackage = await prisma.package.update({
      where: { id: id as string },
      data: {
        shippingRequested: true,
        shippingRequestedAt: new Date(),
        shippingAddressId: userAddress.id
      },
      include: {
        orderItem: true
      }
    });

    // Создаем уведомление для всех админов
    const adminUsers = await prisma.user.findMany({
      where: { isAdmin: true }
    });

    for (const admin of adminUsers) {
      await prisma.notification.create({
        data: {
          userId: admin.id,
          type: 'shipping_request',
          title: '📮 New Shipping Request',
          message: `${dbUser.email} requested shipping for "${pkg.orderItem.title}". Process and ship the package.`
        }
      });
    }

    // Уведомляем пользователя
    await prisma.notification.create({
      data: {
        userId: dbUser.id,
        type: 'shipping_requested',
        title: '📮 Shipping request received',
        message: `Your shipping request for "${pkg.orderItem.title}" has been received. We'll ship it soon!`
      }
    });

    // Отправляем уведомление в Telegram
    const telegramMessage = `
🚢 <b>NEW SHIPPING REQUEST</b>

👤 <b>User:</b> ${dbUser.email}
📦 <b>Package:</b> ${pkg.orderItem.title}
💰 <b>Shipping Cost:</b> ¥${pkg.shippingCost.toLocaleString()}
⚖️ <b>Weight:</b> ${pkg.weight || 'N/A'} kg

<i>Please process and ship this package.</i>
    `.trim();

    await sendTelegramNotification(telegramMessage);

    res.status(200).json({
      success: true,
      message: 'Shipping request sent successfully',
      package: updatedPackage
    });

  } catch (error: any) {
    console.error('Error requesting shipping:', error);
    console.error('Error details:', error.message);
    console.error('Stack:', error.stack);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
}
