import Footer from '../components/Footer';

export default function LegalTaxDisclaimer() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12 flex-1">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Japrix Shipping and Insurance Policy</h1>
        <p className="text-gray-600 mb-2">
          <strong>Effective Date:</strong> October 8, 2025
        </p>
        <p className="text-gray-600 mb-8">
          <strong>Applies to:</strong> All packages shipped from Japrix warehouse (Japan).
        </p>

        <div className="prose prose-lg max-w-none space-y-8">

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Carrier and Service Availability</h2>
            <p className="text-gray-700 mb-2">Japrix utilizes reliable third-party international carriers for all shipments. The primary carriers are:</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Japan Post EMS (Express Mail Service):</strong> Our standard, fast, and fully trackable service.</li>
              <li><strong>FedEx:</strong> Available for certain destinations, oversized items, or upon specific Client request.</li>
            </ul>
            <p className="text-gray-700 mt-2">The availability, delivery speed, and cost of services are determined by the Client's destination country and the dimensions/weight of the final package.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Declaration and Customs Value</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Mandatory Declaration:</strong> Japrix is legally required to declare the accurate contents and value of all shipments to Japanese Customs.</li>
              <li><strong>Valuation:</strong> The declared value for customs purposes will always be the actual purchase price paid for the item(s) by Japrix on behalf of the Client.</li>
              <li><strong>No Undervaluation:</strong> Japrix strictly prohibits and will refuse all requests to declare a lower value than the actual purchase price. Any such request will lead to the cancellation of the shipment and possible account suspension.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Risk of Loss and Damage Transfer</h2>
            <p className="text-gray-700 font-semibold mb-2">
              THE CLIENT ACKNOWLEDGES AND AGREES THAT THE RISK OF LOSS OR DAMAGE TO THE PACKAGE TRANSFERS ENTIRELY TO THE CLIENT AT THE MOMENT JAPRIX DELIVERS THE PACKAGE TO THE SELECTED INTERNATIONAL CARRIER (JAPAN POST EMS OR FEDEX) IN JAPAN.
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Japrix acts solely as the intermediary (proxy buyer) and is not the shipper. Japrix has no control over the package once it is in the carrier's possession.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Insurance and Compensation</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Standard EMS Coverage:</strong> All packages shipped via Japan Post EMS include standard insurance coverage up to a maximum of 20,000 JPY (or its equivalent in SDR). This standard coverage is provided and managed directly by Japan Post.</li>
              <li><strong>Optional Additional Insurance:</strong> The Client has the option to purchase additional insurance coverage up to 2,000,000 JPY during the shipping checkout process for high-value items.</li>
              <li><strong>Compensation Limit:</strong> In the event of loss or damage, Japrix's liability is strictly limited to the compensation amount received from the carrier. Japrix shall not be liable for any loss or damage exceeding the declared insurance value of the shipment.</li>
              <li><strong>No Compensation for Prohibited Items:</strong> Japrix provides no compensation, regardless of insurance status, for items that are damaged, confiscated, or delayed due to the Client ordering items explicitly listed as Prohibited in the Japrix Terms of Service.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Claims Procedure (REQUIRED ACTION BY CLIENT)</h2>
            <p className="text-gray-700 mb-2">The Client is responsible for initiating and managing the insurance claim process.</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Damage Claims:</strong> If a package arrives visibly damaged, the Client MUST immediately inform the delivery agent and their local post office/carrier. The Client must provide photos of the damaged package, the contents, and all packaging materials to their local carrier.</li>
              <li><strong>Lost Packages:</strong> If a package is severely delayed or officially declared lost by the carrier, the Client MUST file a report with their local post office or the delivering branch of the carrier (e.g., FedEx) in their destination country.</li>
              <li><strong>Japrix Assistance:</strong> Japrix will provide all necessary documentation (proof of purchase, invoices, shipping labels) to the Client upon request to support the Client's claim with the local carrier. Japrix will not file the claim directly; the claim must be filed by the recipient (Client) in the destination country.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. Customs, Duties, and Taxes</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Client Responsibility:</strong> The Client is solely and exclusively responsible for the payment of all applicable import duties, tariffs, VAT (Value-Added Tax), GST (Goods and Services Tax), and any local handling fees imposed by the destination country's customs authority.</li>
              <li><strong>Non-Payment of Fees:</strong> If the Client refuses to pay required customs fees, resulting in the package being held, returned, or destroyed by the destination country's customs office:
                <ul className="list-disc pl-6 mt-1">
                  <li>NO REFUND will be issued by Japrix for the item price, service fees, or original shipping costs.</li>
                  <li>The Client will be charged any fees incurred by Japrix for the return shipment or disposal.</li>
                </ul>
              </li>
              <li><strong>Delays:</strong> Japrix is not liable for any delivery delays caused by customs processing in the destination country.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Delivery Address</h2>
            <p className="text-gray-700">
              The Client must ensure the delivery address is accurate and complete. Japrix is not responsible for packages that are lost, delivered incorrectly, or returned due to an incomplete or inaccurate address provided by the Client.
            </p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
