import Footer from '../components/Footer';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12 flex-1">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Japrix Privacy & Cookies Policy</h1>
        <p className="text-gray-600 mb-8">
          <strong>Effective Date:</strong> October 8, 2025<br />
          <strong>Website:</strong> <a href="https://japrix.jp" className="text-blue-600 hover:underline">https://japrix.jp</a><br />
          <strong>Location:</strong> Shinjuku, Tokyo, Japan<br />
          <strong>Email:</strong> <a href="mailto:support@japrix.jp" className="text-blue-600 hover:underline">support@japrix.jp</a>
        </p>

        <div className="prose prose-lg max-w-none space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">1. Introduction</h2>
            <p className="text-gray-700">
              Japrix ("we", "our", or "us") operates the website <a href="https://japrix.jp" className="text-blue-600 hover:underline">https://japrix.jp</a> and related services ("Services"). This Privacy & Cookies Policy explains how we collect, use, and protect your personal information. By using our Services, you agree to this Policy.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">2. Definitions</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Personal Data:</strong> Any information that can identify a living individual, including name, email, address, phone number.</li>
              <li><strong>Usage Data:</strong> Data generated automatically, e.g., IP address, browser type, pages visited.</li>
              <li><strong>Cookies:</strong> Small files stored on your device to improve functionality and user experience.</li>
              <li><strong>Data Controller:</strong> Japrix, responsible for determining purposes and methods of data processing.</li>
              <li><strong>Data Processors / Service Providers:</strong> Third-party companies helping process your data securely.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">3. Information We Collect</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Full name, email, phone number, shipping address.</li>
              <li>Account information: login, order history, balance.</li>
              <li>Payment information: handled securely via Stripe or PayPal. We do not store full card details.</li>
              <li>Usage data: IP address, browser, pages visited.</li>
              <li>Cookies and tracking technologies for analytics and service improvement.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">4. Purpose of Data Processing</h2>
            <p className="text-gray-700 mb-3">We use personal information to:</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Process and deliver orders.</li>
              <li>Manage accounts and verify user identity.</li>
              <li>Handle payments, balance top-ups, and refunds.</li>
              <li>Provide customer support and service updates.</li>
              <li>Monitor and improve service performance and security.</li>
              <li>Comply with legal obligations in Japan and internationally.</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">5. Non-Refundable Account Balance</h2>
            <p className="text-gray-700 font-semibold">
              All funds added to your Japrix account balance are non-refundable under any circumstances.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">6. GDPR Compliance (for EEA Users)</h2>
            <p className="text-gray-700 mb-3">If you are located in the European Economic Area (EEA), you have the following rights:</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li>Access, correct, or delete your personal data.</li>
              <li>Withdraw consent or restrict processing.</li>
              <li>Receive a portable copy of your data.</li>
              <li>File a complaint with a data protection authority.</li>
            </ul>
            <p className="text-gray-700 mt-3">
              Requests can be sent to <a href="mailto:support@japrix.jp" className="text-blue-600 hover:underline">support@japrix.jp</a>.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">7. Users Under 18</h2>
            <p className="text-gray-700">
              Japrix does not knowingly collect data from users under 18 years old. If you are under 18, please do not register or provide personal information.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">8. Data Retention</h2>
            <p className="text-gray-700">
              We retain personal data only as long as necessary to provide services, comply with legal requirements, or resolve disputes.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">9. Data Security</h2>
            <p className="text-gray-700">
              All data is protected with SSL encryption, secure servers, and limited access. While no system is 100% secure, we take reasonable steps to protect your data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">10. Third-Party Services</h2>
            <ul className="list-disc pl-6 space-y-2 text-gray-700">
              <li><strong>Payments:</strong> Stripe, PayPal.</li>
              <li><strong>Shipping:</strong> Japan Post EMS.</li>
              <li><strong>Analytics & Tracking:</strong> Google Analytics, optional remarketing tools.</li>
            </ul>
            <p className="text-gray-700 mt-3">All third-party services comply with their own privacy policies.</p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">11. Cookies</h2>
            <p className="text-gray-700">
              We use cookies to maintain session state, remember preferences, and analyze usage. You can disable cookies in your browser, but some features may not work.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">12. Contact Information</h2>
            <p className="text-gray-700">
              For questions about this Privacy Policy, contact us at:<br />
              📧 <a href="mailto:support@japrix.jp" className="text-blue-600 hover:underline">support@japrix.jp</a>
            </p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
