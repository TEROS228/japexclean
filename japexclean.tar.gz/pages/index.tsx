import Link from "next/link";
import Image from "next/image";
import { useState, Fragment, useRef, useEffect } from "react";
import { Dialog, Transition } from "@headlessui/react";
import useUserContext from "@/context/UserContext";
import { useRouter } from "next/router";

import { allCategories as categories } from "@/data/categories";
import PrivacyNotice from '@/components/PrivacyNotice';
import Footer from '@/components/Footer';

// Hook для анимации при скролле
function useScrollAnimation() {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const hasTriggered = useRef(false);

  useEffect(() => {
    const currentRef = ref.current;
    if (!currentRef) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasTriggered.current) {
          hasTriggered.current = true;
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(currentRef);

    return () => {
      observer.disconnect();
    };
  }, []);

  return [ref, isVisible] as const;
}

// Hook для анимации чисел
function useCountUp(end: number, duration: number = 2000, shouldStart: boolean = false) {
  const [count, setCount] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!shouldStart || hasAnimated.current) return;

    hasAnimated.current = true;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);

      const currentCount = Math.floor(progress * end);
      setCount(currentCount);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [end, duration, shouldStart]);

  return count;
}

export default function Home() {
  const { user, login, signup, logout } = useUserContext();
  const router = useRouter();

  const [marketplace, setMarketplace] = useState("Rakuten");
  const [selectedCategory, setSelectedCategory] = useState<null | typeof categories[0]>(null);
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);

  // Scroll animations
  const [heroRef, heroVisible] = useScrollAnimation();
  const [statsRef, statsVisible] = useScrollAnimation();
  const [howItWorksRef, howItWorksVisible] = useScrollAnimation();
  const [categoriesRef, categoriesVisible] = useScrollAnimation();

  // Анимированные числа для статистики
  const products = useCountUp(50000, 2000, statsVisible);
  const customers = useCountUp(10000, 2000, statsVisible);
  const countries = useCountUp(150, 2000, statsVisible);

  // Параллакс эффект
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);

  const [signUpForm, setSignUpForm] = useState({
    name: "",
    secondName: "",
    email: "",
    password: "",
  });
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
  });

  const [searchQuery, setSearchQuery] = useState("");

  const dropdownRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function onClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setCategoryDropdownOpen(false);
      }
    }
    if (categoryDropdownOpen) {
      document.addEventListener("mousedown", onClickOutside);
    }
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [categoryDropdownOpen]);

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    signup(signUpForm);
    setSignUpForm({ name: "", secondName: "", email: "", password: "" });
    setIsSignUpOpen(false);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(loginForm.email, loginForm.password);
    if (success) setIsLoginOpen(false);
    setLoginForm({ email: "", password: "" });
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      router.push(`/search?query=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <main className="min-h-screen bg-white text-gray-900 font-sans antialiased">
      {/* Уведомление о приватности */}
      <PrivacyNotice />

      {/* Hero Section - Premium Modern Design */}
      <section ref={heroRef as React.RefObject<HTMLElement>} className="relative overflow-hidden bg-gradient-to-b from-gray-50 to-white">
        {/* Background decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
          <div className="absolute top-1/2 left-1/2 w-80 h-80 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className={`space-y-8 ${heroVisible ? 'opacity-100' : 'opacity-0'}`}>
              <div className={`inline-flex items-center px-4 py-2 bg-green-50 border border-green-100 rounded-full ${heroVisible ? 'animate-fadeInUp' : ''}`}>
                <span className="text-xs font-semibold text-green-700 uppercase tracking-wide">Trusted by 10,000+ customers worldwide</span>
              </div>

              <h1 className={`text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight tracking-tight text-gray-900 ${heroVisible ? 'animate-fadeInUp delay-100' : ''}`}>
                Your gateway to
                <span className="block mt-2 bg-gradient-to-r from-green-600 via-green-500 to-emerald-600 bg-clip-text text-transparent animate-gradient">
                  Japanese excellence
                </span>
              </h1>

              <p className={`text-xl text-gray-600 leading-relaxed max-w-xl ${heroVisible ? 'animate-fadeInUp delay-200' : ''}`}>
                Access authentic products from Japan's leading marketplaces. Professional service, transparent pricing, worldwide delivery.
              </p>

              <div className={`flex flex-col sm:flex-row gap-4 ${heroVisible ? 'animate-fadeInUp delay-300' : ''}`}>
                <button
                  onClick={() => router.push("/category/100371")}
                  className="shimmer group relative px-8 py-4 bg-gray-900 text-white font-semibold rounded-lg overflow-hidden transition-all hover:shadow-2xl hover:scale-105 active:scale-100"
                >
                  <span className="relative z-10">Explore Products</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-green-600 to-emerald-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>

                <button
                  onClick={() => router.push("/all-subcategories")}
                  className="shimmer px-8 py-4 bg-white text-gray-900 font-semibold rounded-lg border-2 border-gray-200 hover:border-gray-900 hover:shadow-lg transition-all hover:scale-105 active:scale-100"
                >
                  Browse Categories
                </button>
              </div>

              {/* Trust badges */}
              <div className={`flex items-center gap-6 pt-4 ${heroVisible ? 'animate-fadeInUp delay-400' : ''}`}>
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-sm font-medium text-gray-600">Secure Payment</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-sm font-medium text-gray-600">Fast Shipping</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-sm font-medium text-gray-600">24/7 Support</span>
                </div>
              </div>
            </div>

            <div
              className={`relative ${heroVisible ? 'animate-slideInRight delay-200' : 'opacity-0'}`}
              style={{ transform: `translateY(${scrollY * 0.1}px)` }}
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl animate-float group cursor-pointer">
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <Image
                  src="/hero.jpg"
                  alt="Japanese Products"
                  width={700}
                  height={600}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  priority
                />
                {/* Overlay badge */}
                <div className="absolute bottom-8 left-8 bg-white/95 backdrop-blur-sm px-6 py-4 rounded-xl shadow-lg hover:scale-105 transition-transform duration-300">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900">Authentic Products</p>
                      <p className="text-xs text-gray-600">Verified Japanese sellers</p>
                    </div>
                  </div>
                </div>
              </div>
              {/* Decorative dots */}
              <div className="absolute -z-10 -top-4 -right-4 w-72 h-72 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full filter blur-3xl opacity-30 animate-pulse"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section - NEW! */}
      <section ref={statsRef as React.RefObject<HTMLElement>} className="bg-white py-16 border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className={`text-center transition-all duration-700 ${statsVisible ? 'animate-fadeInScale opacity-100' : 'opacity-0'}`}>
              <div className="text-5xl font-bold text-gray-900 mb-2">
                {products > 0 ? products.toLocaleString() : '50,000'}+
              </div>
              <div className="text-gray-600 font-medium">Products Available</div>
            </div>
            <div className={`text-center transition-all duration-700 ${statsVisible ? 'animate-fadeInScale delay-100 opacity-100' : 'opacity-0'}`}>
              <div className="text-5xl font-bold text-gray-900 mb-2">
                {customers > 0 ? customers.toLocaleString() : '10,000'}+
              </div>
              <div className="text-gray-600 font-medium">Happy Customers</div>
            </div>
            <div className={`text-center transition-all duration-700 ${statsVisible ? 'animate-fadeInScale delay-200 opacity-100' : 'opacity-0'}`}>
              <div className="text-5xl font-bold text-gray-900 mb-2">
                {countries > 0 ? countries : '150'}+
              </div>
              <div className="text-gray-600 font-medium">Countries Served</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section ref={howItWorksRef as React.RefObject<HTMLElement>} className="bg-white py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className={`text-center mb-20 ${howItWorksVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
            <div className="inline-block px-4 py-2 bg-gray-50 rounded-full mb-6">
              <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Simple Process</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4 tracking-tight">
              How It Works
            </h2>
            <p className="text-lg text-gray-500 max-w-2xl mx-auto">
              Four simple steps from browsing to delivery
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {/* Step 1 */}
            <div className={`relative group ${howItWorksVisible ? 'animate-fadeInUp delay-100' : 'opacity-0'}`}>
              <div className="card-3d bg-white border border-gray-100 rounded-xl p-8 text-center transition-all duration-300 hover:shadow-lg hover:border-gray-200">
                <div className="mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-900 rounded-lg mb-4 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <div className="text-sm font-semibold text-gray-400 mb-2">STEP 01</div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Browse & Select</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Choose from thousands of authentic Japanese products on Rakuten and Yahoo Shopping
                </p>
              </div>
              {/* Connector line */}
              <div className="hidden lg:block absolute top-12 left-full w-12 h-0.5 bg-gray-200"></div>
            </div>

            {/* Step 2 */}
            <div className={`relative group ${howItWorksVisible ? 'animate-fadeInUp delay-200' : 'opacity-0'}`}>
              <div className="card-3d bg-white border border-gray-100 rounded-xl p-8 text-center transition-all duration-300 hover:shadow-lg hover:border-gray-200">
                <div className="mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-900 rounded-lg mb-4 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div className="text-sm font-semibold text-gray-400 mb-2">STEP 02</div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Place Order</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Complete your order and we'll purchase the item for you from the Japanese marketplace
                </p>
              </div>
              {/* Connector line */}
              <div className="hidden lg:block absolute top-12 left-full w-12 h-0.5 bg-gray-200"></div>
            </div>

            {/* Step 3 */}
            <div className={`relative group ${howItWorksVisible ? 'animate-fadeInUp delay-300' : 'opacity-0'}`}>
              <div className="card-3d bg-white border border-gray-100 rounded-xl p-8 text-center transition-all duration-300 hover:shadow-lg hover:border-gray-200">
                <div className="mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-900 rounded-lg mb-4 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <div className="text-sm font-semibold text-gray-400 mb-2">STEP 03</div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Warehouse Processing</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Item arrives at our warehouse. Choose extra services: package photos, double protection, consolidation
                </p>
              </div>
              {/* Connector line */}
              <div className="hidden lg:block absolute top-12 left-full w-12 h-0.5 bg-gray-200"></div>
            </div>

            {/* Step 4 */}
            <div className={`relative group ${howItWorksVisible ? 'animate-fadeInUp delay-400' : 'opacity-0'}`}>
              <div className="card-3d bg-white border border-gray-100 rounded-xl p-8 text-center transition-all duration-300 hover:shadow-lg hover:border-gray-200">
                <div className="mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-900 rounded-lg mb-4 group-hover:scale-110 transition-transform">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                    </svg>
                  </div>
                  <div className="text-sm font-semibold text-gray-400 mb-2">STEP 04</div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Shipping & Delivery</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Pay the shipping invoice and receive your package safely at your doorstep
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Feature Section - Right Side Large Image */}
      <section className="relative bg-white py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <div className="space-y-6 lg:pr-12">
              <div className="inline-block px-4 py-2 bg-green-50 border border-green-100 rounded-full">
                <span className="text-xs font-semibold text-green-700 uppercase tracking-wide">Why Choose Japoriax</span>
              </div>

              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 leading-tight">
                Your trusted partner for Japanese shopping
              </h2>

              <p className="text-lg text-gray-600 leading-relaxed">
                We connect you with authentic Japanese products from trusted marketplaces, handling everything from purchase to international delivery.
              </p>

              <div className="space-y-4 pt-4">
                {/* Feature 1 */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-1">100% Authentic Products</h3>
                    <p className="text-gray-600">Direct from official Japanese retailers - Rakuten and Yahoo Shopping</p>
                  </div>
                </div>

                {/* Feature 2 */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-1">Transparent Pricing</h3>
                    <p className="text-gray-600">No hidden fees - see exact costs before you order</p>
                  </div>
                </div>

                {/* Feature 3 */}
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900 mb-1">Worldwide Delivery</h3>
                    <p className="text-gray-600">Safe and secure shipping to 150+ countries</p>
                  </div>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={() => router.push("/how-to-order")}
                  className="group inline-flex items-center gap-2 bg-gray-900 text-white px-8 py-4 rounded-lg font-semibold hover:bg-gray-800 hover:shadow-lg transition-all hover:scale-105"
                >
                  Learn More
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </button>
              </div>
            </div>

            {/* Right Image - Takes up ~60% of right side */}
            <div className="relative lg:absolute lg:right-0 lg:top-1/2 lg:-translate-y-1/2 lg:w-[45%] h-[500px] lg:h-[600px]">
              <div className="relative h-full overflow-hidden group">
                <Image
                  src="/feature-image.jpg"
                  alt="Japanese Shopping Experience"
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Popular Categories Section - Poster Style */}
      <section ref={categoriesRef as React.RefObject<HTMLElement>} className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-black">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-red-500/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto relative">
          <div className={`text-center mb-16 ${categoriesVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
            <div className="inline-block px-4 py-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full mb-6">
              <span className="text-xs font-semibold text-white uppercase tracking-widest">Discover Japan</span>
            </div>
            <h2 className="text-5xl lg:text-6xl font-black text-white mb-4 tracking-tight">
              Shop by <span className="bg-gradient-to-r from-red-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">Category</span>
            </h2>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              From Tokyo's streets to your doorstep
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Fashion */}
            <Link href="/category/100371" className={`group ${categoriesVisible ? 'animate-fadeInScale delay-100' : 'opacity-0'}`}>
              <div className="relative h-80 rounded-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02] will-change-transform">
                <div className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg group-hover:shadow-2xl group-hover:shadow-red-500/50 transition-shadow duration-300">
                  {/* Image with Overlay */}
                  <div className="absolute inset-0">
                    <Image
                      src="/category-fashion.jpg"
                      alt="Fashion"
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                    <div className="absolute inset-0 bg-red-600/20 mix-blend-multiply group-hover:bg-red-600/30 transition-all duration-500"></div>
                  </div>
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="backdrop-blur-sm bg-black/30 rounded-xl p-4 border border-white/10 transform transition-all duration-300 group-hover:bg-black/50">
                      <h3 className="text-2xl font-black text-white mb-2 tracking-tight">Fashion</h3>
                      <p className="text-gray-200 text-sm mb-3 leading-relaxed">
                        Japanese streetwear & designer brands
                      </p>
                      <span className="inline-flex items-center text-white font-bold text-sm group-hover:gap-2 transition-all">
                        Explore
                        <svg className="w-4 h-4 ml-1 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>

            {/* Electronics */}
            <Link href="/category/100026" className={`group ${categoriesVisible ? 'animate-fadeInScale delay-200' : 'opacity-0'}`}>
              <div className="relative h-80 rounded-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02] will-change-transform">
                <div className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg group-hover:shadow-2xl group-hover:shadow-blue-500/50 transition-shadow duration-300">
                  {/* Image with Overlay */}
                  <div className="absolute inset-0">
                    <Image
                      src="/category-electronics.jpg"
                      alt="Electronics"
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                    <div className="absolute inset-0 bg-blue-600/20 mix-blend-multiply group-hover:bg-blue-600/30 transition-all duration-500"></div>
                  </div>
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="backdrop-blur-sm bg-black/30 rounded-xl p-4 border border-white/10 transform transition-all duration-300 group-hover:bg-black/50">
                      <h3 className="text-2xl font-black text-white mb-2 tracking-tight">Electronics</h3>
                      <p className="text-gray-200 text-sm mb-3 leading-relaxed">
                        Latest gadgets & audio equipment
                      </p>
                      <span className="inline-flex items-center text-white font-bold text-sm group-hover:gap-2 transition-all">
                        Explore
                        <svg className="w-4 h-4 ml-1 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>

            {/* Anime & Collectibles */}
            <Link href="/category/101240" className={`group ${categoriesVisible ? 'animate-fadeInScale delay-300' : 'opacity-0'}`}>
              <div className="relative h-80 rounded-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02] will-change-transform">
                <div className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg group-hover:shadow-2xl group-hover:shadow-purple-500/50 transition-shadow duration-300">
                  {/* Image with Overlay */}
                  <div className="absolute inset-0">
                    <Image
                      src="/category-anime.jpg"
                      alt="Anime & Hobby"
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                    <div className="absolute inset-0 bg-purple-600/20 mix-blend-multiply group-hover:bg-purple-600/30 transition-all duration-500"></div>
                  </div>
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="backdrop-blur-sm bg-black/30 rounded-xl p-4 border border-white/10 transform transition-all duration-300 group-hover:bg-black/50">
                      <h3 className="text-2xl font-black text-white mb-2 tracking-tight">Anime & Hobby</h3>
                      <p className="text-gray-200 text-sm mb-3 leading-relaxed">
                        Figures, manga & collectibles
                      </p>
                      <span className="inline-flex items-center text-white font-bold text-sm group-hover:gap-2 transition-all">
                        Explore
                        <svg className="w-4 h-4 ml-1 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>

            {/* Beauty & Cosmetics */}
            <Link href="/category/100938" className={`group ${categoriesVisible ? 'animate-fadeInScale delay-400' : 'opacity-0'}`}>
              <div className="relative h-80 rounded-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02] will-change-transform">
                <div className="absolute inset-0 rounded-2xl overflow-hidden shadow-lg group-hover:shadow-2xl group-hover:shadow-pink-500/50 transition-shadow duration-300">
                  {/* Image with Overlay */}
                  <div className="absolute inset-0">
                    <Image
                      src="/category-beauty.jpg"
                      alt="Beauty & Care"
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
                    <div className="absolute inset-0 bg-pink-600/20 mix-blend-multiply group-hover:bg-pink-600/30 transition-all duration-500"></div>
                  </div>
                  {/* Content */}
                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <div className="backdrop-blur-sm bg-black/30 rounded-xl p-4 border border-white/10 transform transition-all duration-300 group-hover:bg-black/50">
                      <h3 className="text-2xl font-black text-white mb-2 tracking-tight">Beauty & Care</h3>
                      <p className="text-gray-200 text-sm mb-3 leading-relaxed">
                        Japanese skincare & cosmetics
                      </p>
                      <span className="inline-flex items-center text-white font-bold text-sm group-hover:gap-2 transition-all">
                        Explore
                        <svg className="w-4 h-4 ml-1 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                        </svg>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          </div>

          {/* View All Categories Button */}
          <div className={`text-center mt-16 ${categoriesVisible ? 'animate-fadeInUp delay-500' : 'opacity-0'}`}>
            <button
              onClick={() => {
                sessionStorage.setItem('openCategoryMenu', 'true');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="group inline-flex items-center gap-3 bg-white text-gray-900 px-10 py-5 rounded-xl font-black text-lg hover:bg-gray-100 hover:shadow-2xl transition-all duration-300 hover:scale-105 border-4 border-white/20"
            >
              View All Categories
              <svg className="w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </button>
          </div>
        </div>
      </section>

      {/* Модалка регистрации */}
      <Transition appear show={isSignUpOpen} as={Fragment}>
        <Dialog as="div" className="relative z-20" onClose={() => setIsSignUpOpen(false)}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-150"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-30" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-200"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-150"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title className="text-lg font-bold text-gray-800 mb-4">Sign Up</Dialog.Title>
                  <form onSubmit={handleSignUpSubmit} className="space-y-4">
                    <input
                      type="text"
                      placeholder="Name"
                      required
                      value={signUpForm.name}
                      onChange={(e) => setSignUpForm({ ...signUpForm, name: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <input
                      type="text"
                      placeholder="Second Name"
                      required
                      value={signUpForm.secondName}
                      onChange={(e) => setSignUpForm({ ...signUpForm, secondName: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <input
                      type="email"
                      placeholder="Email"
                      required
                      value={signUpForm.email}
                      onChange={(e) => setSignUpForm({ ...signUpForm, email: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <input
                      type="password"
                      placeholder="Password"
                      required
                      value={signUpForm.password}
                      onChange={(e) => setSignUpForm({ ...signUpForm, password: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <button
                      type="submit"
                      className="w-full bg-[#10B981] text-white py-2 rounded-lg hover:bg-[#0f9c6e] transition"
                    >
                      Submit
                    </button>
                  </form>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>

      {/* Модалка входа */}
      <Transition appear show={isLoginOpen} as={Fragment}>
        <Dialog as="div" className="relative z-20" onClose={() => setIsLoginOpen(false)}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-150"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-30" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-200"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-150"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title className="text-lg font-bold text-gray-800 mb-4">Log In</Dialog.Title>
                  <form onSubmit={handleLoginSubmit} className="space-y-4">
                    <input
                      type="email"
                      placeholder="Email"
                      required
                      value={loginForm.email}
                      onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <input
                      type="password"
                      placeholder="Password"
                      required
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      className="w-full border rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#10B981]"
                    />
                    <button
                      type="submit"
                      className="w-full bg-[#10B981] text-white py-2 rounded-lg hover:bg-[#0f9c6e] transition"
                    >
                      Log In
                    </button>
                  </form>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>

      {/* Модалка с информацией о пользователе */}
      <Transition appear show={isInfoOpen} as={Fragment}>
        <Dialog as="div" className="relative z-20" onClose={() => setIsInfoOpen(false)}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-200"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-150"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-30" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-200"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-150"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-sm transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title className="text-lg font-bold text-gray-800 mb-4">My Info</Dialog.Title>
                  {user ? (
                    <div className="space-y-2">
                      <p>
                        <b>Name:</b> {user.name} {user.secondName}
                      </p>
                      <p>
                        <b>Email:</b> {user.email}
                      </p>
                    </div>
                  ) : (
                    <p>You are not logged in.</p>
                  )}
                  <button
                    className="mt-6 w-full bg-[#10B981] text-white py-2 rounded-lg hover:bg-[#0f9c6e] transition"
                    onClick={() => setIsInfoOpen(false)}
                  >
                    Close
                  </button>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
      <Footer />
    </main>
  );
}
