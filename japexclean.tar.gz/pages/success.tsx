// success.tsx
import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { getAuthToken, updateUserBalance } from '@/lib/auth'; // ← Исправленный импорт

export default function SuccessPage() {
  const router = useRouter();
  const [processing, setProcessing] = useState(true);
  const [success, setSuccess] = useState(false);
  const [hasProcessed, setHasProcessed] = useState(false);

  useEffect(() => {
    // Предотвращаем повторную обработку
    if (hasProcessed) {
      console.log('⚠️ Payment already processed, skipping...');
      return;
    }

    const processPayment = async () => {
      const query = new URLSearchParams(window.location.search);
      const sessionId = query.get('session_id');

      if (!sessionId) {
        window.location.href = '/cart?topup=error';
        return;
      }

      const token = getAuthToken(); // ← Теперь будет работать!
      if (!token) {
        window.location.href = '/auth';
        return;
      }

      // Проверяем, не был ли этот session_id уже обработан
      const processedSessions = JSON.parse(localStorage.getItem('processedSessions') || '[]');
      if (processedSessions.includes(sessionId)) {
        console.log('✅ This session was already processed, showing success screen');
        setSuccess(true);
        setProcessing(false);
        setHasProcessed(true);
        return;
      }

      try {
        console.log('Processing payment with session:', sessionId);
        setHasProcessed(true);
        
        // 1. Проверяем платеж
        const verifyResponse = await fetch(`/api/balance/verify?session_id=${sessionId}`);
        if (!verifyResponse.ok) throw new Error(`Verify failed: ${verifyResponse.status}`);
        
        const verifyData = await verifyResponse.json();
        console.log('Verification result:', verifyData);

        if (!verifyData.paid || !verifyData.amountAfterFee) {
          throw new Error(verifyData.error || 'Payment not completed');
        }

        // 2. Обновляем баланс
        const updateResponse = await fetch('/api/balance/update', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ 
            amount: verifyData.amountAfterFee,
            description: 'Stripe top up',
            sessionId: sessionId
          }),
        });

        if (!updateResponse.ok) {
          const errorData = await updateResponse.json();
          throw new Error(errorData.error || 'Balance update failed');
        }

        const updateData = await updateResponse.json();
        console.log('Balance updated successfully:', updateData.newBalance);
        
        // 3. Обновляем localStorage
        updateUserBalance(updateData.newBalance); // ← Исправленная функция!
        
        // 4. Отправляем событие
        window.dispatchEvent(new Event('balanceUpdated'));

        // 5. Сохраняем session_id как обработанный
        const processedSessions = JSON.parse(localStorage.getItem('processedSessions') || '[]');
        processedSessions.push(sessionId);
        localStorage.setItem('processedSessions', JSON.stringify(processedSessions));

        // 6. Показываем успех вместо редиректа
        console.log('✅ Payment completed successfully - showing success screen (no redirect)');
        setSuccess(true);
        setProcessing(false);

      } catch (error: any) {
        console.error('Payment processing error:', error);
        setHasProcessed(false); // Сбрасываем флаг при ошибке
        window.location.href = '/cart?topup=error';
      }
    };

    processPayment();
  }, [hasProcessed]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        {processing ? (
          <div className="bg-white rounded-2xl shadow-2xl p-8 text-center animate-fade-in">
            {/* Animated Loading Spinner */}
            <div className="mb-6 flex justify-center">
              <div className="relative w-20 h-20">
                <div className="absolute inset-0 border-4 border-green-200 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-green-600 rounded-full border-t-transparent animate-spin"></div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-gray-900 mb-3">
              Processing Payment
            </h2>
            <p className="text-gray-600">
              Please wait while we confirm your transaction...
            </p>

            {/* Animated dots */}
            <div className="flex justify-center gap-2 mt-6">
              <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-green-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
          </div>
        ) : success ? (
          <div className="bg-white rounded-2xl shadow-2xl p-8 text-center animate-scale-in">
            {/* Success Checkmark Animation */}
            <div className="mb-6 flex justify-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center animate-bounce-once">
                <svg
                  className="w-12 h-12 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={3}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
            </div>

            <h2 className="text-3xl font-bold text-gray-900 mb-3">
              Payment Successful!
            </h2>
            <p className="text-gray-600 mb-6">
              Your balance has been updated successfully
            </p>

            <div className="flex flex-col gap-3">
              <Link href="/cart">
                <button className="w-full px-8 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl hover:from-green-600 hover:to-green-700 transition-all hover:scale-105 active:scale-95 shadow-lg hover:shadow-xl">
                  Go to Cart
                </button>
              </Link>

              <Link href="/">
                <button className="w-full px-8 py-3 border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 hover:border-gray-300 transition-all hover:scale-105 active:scale-95">
                  Continue Shopping
                </button>
              </Link>
            </div>
          </div>
        ) : null}
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes scale-in {
          0% {
            opacity: 0;
            transform: scale(0.9);
          }
          50% {
            transform: scale(1.02);
          }
          100% {
            opacity: 1;
            transform: scale(1);
          }
        }

        @keyframes bounce-once {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }

        .animate-scale-in {
          animation: scale-in 0.6s ease-out;
        }

        .animate-bounce-once {
          animation: bounce-once 0.6s ease-out;
        }
      `}</style>
    </div>
  );
}