// pages/success.tsx
import { useRouter } from "next/router";

export default function SuccessPage() {
  const router = useRouter();
  const { session_id } = router.query;

  return (
    <main className="p-6 text-center">
      <h1 className="text-2xl font-bold text-green-600">✅ Оплата прошла успешно!</h1>
      <p className="mt-2">Спасибо за заказ. Session ID: {session_id}</p>
      <button
        onClick={() => router.push("/")}
        className="mt-4 bg-blue-500 text-white px-4 py-2 rounded"
      >
        Вернуться на главную
      </button>
    </main>
  );
}
