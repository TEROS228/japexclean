import { useState } from "react";
import  useUserContext  from "@/context/UserContext";

export default function TopUpPage() {
  const [amount, setAmount] = useState(10);
  // const { topUp } = useUserContext(); // TODO: Add topUp to UserContext

  const handleTopUp = async () => {
    const res = await fetch("/api/stripe/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount }),
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  };

  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-4">Пополнение баланса</h1>
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
        className="border px-3 py-2 rounded mr-2"
      />
      <button onClick={handleTopUp} className="bg-green-500 text-white px-4 py-2 rounded">
        Пополнить через Stripe
      </button>
    </div>
  );
}
