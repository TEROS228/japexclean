-- AlterTable
ALTER TABLE "packages" ADD COLUMN "consolidateWith" TEXT;
