// Microsoft Translator API - Azure Cognitive Services
// Docs: https://learn.microsoft.com/azure/cognitive-services/translator/

export type Language = 'ja' | 'en' | 'es' | 'de' | 'th' | 'fil' | 'pt';

interface TranslationCache {
  [key: string]: string;
}

const cache: TranslationCache = {};

// localStorage ключ для кеша
const CACHE_KEY = 'translation_cache_v1';
const CACHE_EXPIRY_DAYS = 30;

// Загружаем кеш из localStorage при инициализации
if (typeof window !== 'undefined') {
  try {
    const stored = localStorage.getItem(CACHE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Проверяем срок годности кеша
      if (parsed.timestamp && Date.now() - parsed.timestamp < CACHE_EXPIRY_DAYS * 24 * 60 * 60 * 1000) {
        Object.assign(cache, parsed.data || {});
      } else {
        // Кеш устарел, удаляем
        localStorage.removeItem(CACHE_KEY);
      }
    }
  } catch (error) {
    console.error('Failed to load translation cache:', error);
  }
}

// Сохраняем кеш в localStorage
function saveCache() {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify({
        timestamp: Date.now(),
        data: cache
      }));
    } catch (error) {
      console.error('Failed to save translation cache:', error);
    }
  }
}

export async function translateText(
  text: string,
  fromLang: Language,
  toLang: Language
): Promise<string> {
  if (fromLang === toLang) return text;
  if (!text.trim()) return text;

  const cacheKey = `${fromLang}-${toLang}-${text}`;
  if (cache[cacheKey]) {
    return cache[cacheKey];
  }

  try {
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        texts: [text],
        fromLang,
        toLang,
      }),
    });

    if (!response.ok) {
      console.error('Translation API error:', response.status);
      return text;
    }

    const responseText = await response.text();

    if (!responseText || responseText.trim() === '') {
      console.error('Empty response from translation API');
      return text;
    }

    try {
      const data = JSON.parse(responseText);

      if (data.translations?.[0]) {
        const translated = data.translations[0];
        cache[cacheKey] = translated;
        saveCache(); // Сохраняем в localStorage
        return translated;
      }

      return text; // Возвращаем оригинал при ошибке
    } catch (jsonError) {
      console.error('JSON parse error in translateText:', jsonError);
      return text;
    }
  } catch (error) {
    console.error('Translation error:', error);
    return text;
  }
}

// Функция для перевода батча текстов
async function translateBatch(
  texts: string[],
  fromLang: Language,
  toLang: Language
): Promise<string[]> {
  if (fromLang === toLang) return texts;

  // Проверяем кеш для каждого текста
  const uncachedIndices: number[] = [];
  const uncachedTexts: string[] = [];
  const results: string[] = [];

  texts.forEach((text, index) => {
    const cacheKey = `${fromLang}-${toLang}-${text}`;
    if (cache[cacheKey]) {
      results[index] = cache[cacheKey];
    } else {
      uncachedIndices.push(index);
      uncachedTexts.push(text);
    }
  });

  // Если все тексты в кеше, возвращаем их
  if (uncachedTexts.length === 0) {
    return results;
  }

  try {
    const response = await fetch('/api/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        texts: uncachedTexts,
        fromLang,
        toLang,
      }),
    });

    if (!response.ok) {
      console.error('Batch translation API error:', response.status);
      // Возвращаем оригинальные тексты для непереведенных
      uncachedIndices.forEach((originalIndex, i) => {
        results[originalIndex] = uncachedTexts[i];
      });
      return results;
    }

    const responseText = await response.text();

    if (!responseText || responseText.trim() === '') {
      console.error('Empty response from batch translation API');
      uncachedIndices.forEach((originalIndex, i) => {
        results[originalIndex] = uncachedTexts[i];
      });
      return results;
    }

    try {
      const data = JSON.parse(responseText);

      if (data.translations && Array.isArray(data.translations)) {
        data.translations.forEach((translated: string, i: number) => {
          const originalIndex = uncachedIndices[i];
          results[originalIndex] = translated;
          // Кешируем перевод
          const cacheKey = `${fromLang}-${toLang}-${uncachedTexts[i]}`;
          cache[cacheKey] = translated;
        });
        saveCache(); // Сохраняем весь батч в localStorage
      }

      return results;
    } catch (jsonError) {
      console.error('JSON parse error in translateBatch:', jsonError);
      // Возвращаем оригинальные тексты
      uncachedIndices.forEach((originalIndex, i) => {
        results[originalIndex] = uncachedTexts[i];
      });
      return results;
    }
  } catch (error) {
    console.error('Batch translation error:', error);
    // Если батч не сработал, переводим по одному
    return Promise.all(texts.map(text => translateText(text, fromLang, toLang)));
  }
}

// Функция для перевода всех текстовых узлов на странице
export async function translatePage(targetLang: Language) {
  if (targetLang === 'ja') {
    // Перезагружаем страницу для возврата к японскому
    window.location.reload();
    return;
  }

  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode: (node) => {
        // Пропускаем скрипты и стили
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;

        const tagName = parent.tagName.toLowerCase();
        if (['script', 'style', 'noscript', 'code'].includes(tagName)) {
          return NodeFilter.FILTER_REJECT;
        }

        // Пропускаем пустые или только пробельные узлы
        const text = node.textContent?.trim();
        if (!text || text.length === 0) {
          return NodeFilter.FILTER_REJECT;
        }

        return NodeFilter.FILTER_ACCEPT;
      },
    }
  );

  const textNodes: { node: Node; text: string }[] = [];
  let currentNode: Node | null;

  while ((currentNode = walker.nextNode())) {
    const text = currentNode.textContent?.trim();
    if (text) {
      textNodes.push({ node: currentNode, text });
    }
  }

  console.log(`[Translator] Found ${textNodes.length} text nodes to translate`);

  // Переводим батчами по 10 узлов
  const batchSize = 10;
  for (let i = 0; i < textNodes.length; i += batchSize) {
    const batch = textNodes.slice(i, i + batchSize);
    const texts = batch.map(item => item.text);

    const translations = await translateBatch(texts, 'ja', targetLang);

    // Применяем переводы
    batch.forEach((item, index) => {
      if (item.node.textContent && translations[index]) {
        item.node.textContent = translations[index];
      }
    });

    console.log(`[Translator] Translated batch ${Math.floor(i / batchSize) + 1}/${Math.ceil(textNodes.length / batchSize)}`);
  }

  console.log('[Translator] Translation complete!');
}
