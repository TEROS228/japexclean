import { useState, useRef, useEffect } from 'react';
import { calculateEMSCost, getChargeableWeight } from '@/lib/emsRates';
import { calculateECMSCost, getECMSChargeableWeight, ecmsDestinations, ECMSDestination } from '@/lib/ecmsRates';
import { useCurrency } from '@/context/CurrencyContext';
import { Package, Ruler, Weight, MapPin, Calculator, Plane, Camera, Package2, Layers, ChevronDown } from 'lucide-react';

type ShippingService = 'EMS' | 'ECMS';

const emsZones = [
  { zone: 1, name: 'Zone 1', desc: 'China, S.Korea, Taiwan' },
  { zone: 2, name: 'Zone 2', desc: 'Hong Kong, Singapore, Thailand' },
  { zone: 3, name: 'Zone 3', desc: 'Canada, Europe, Australia' },
  { zone: 5, name: 'Zone 5', desc: 'S.America, Africa' },
] as const;

export default function ShippingCalculator() {
  const { formatPrice } = useCurrency();

  // Service selection
  const [service, setService] = useState<ShippingService>('EMS');

  // Input states
  const [weightGrams, setWeightGrams] = useState<string>('');
  const [length, setLength] = useState<string>('');
  const [width, setWidth] = useState<string>('');
  const [height, setHeight] = useState<string>('');

  // EMS zones: 1, 2, 3, 5 (Zone 4 suspended)
  const [emsZone, setEmsZone] = useState<1 | 2 | 3 | 5>(3);

  // ECMS destinations
  const [ecmsDestination, setEcmsDestination] = useState<ECMSDestination>('usa');

  // Dropdown states
  const [emsDropdownOpen, setEmsDropdownOpen] = useState(false);

  // Refs for click outside
  const emsDropdownRef = useRef<HTMLDivElement>(null);

  // Additional services
  const [photoService, setPhotoService] = useState(false);
  const [consolidation, setConsolidation] = useState(false);

  // Result states
  const [shippingCost, setShippingCost] = useState<number | null>(null);
  const [chargeableWeight, setChargeableWeight] = useState<number | null>(null);
  const [volumetricWeight, setVolumetricWeight] = useState<number | null>(null);
  const [calculationKey, setCalculationKey] = useState(0);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (emsDropdownRef.current && !emsDropdownRef.current.contains(event.target as Node)) {
        setEmsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleCalculate = () => {
    const grams = parseFloat(weightGrams);
    const l = parseFloat(length);
    const wi = parseFloat(width);
    const h = parseFloat(height);

    if (isNaN(grams) || grams <= 0) {
      alert('Please enter a valid weight in grams');
      return;
    }

    // Сбрасываем предыдущие результаты для принудительного обновления
    setShippingCost(null);
    setChargeableWeight(null);
    setVolumetricWeight(null);

    // Небольшая задержка для принудительного ререндера
    setTimeout(() => {
      // Конвертируем граммы в килограммы
      const actualWeight = grams / 1000;

      // Если размеры указаны, рассчитываем объемный вес
      let volWeight = 0;
      let finalWeight = actualWeight;

      // Проверяем что ВСЕ размеры заполнены и валидны
      const hasDimensions = !isNaN(l) && !isNaN(wi) && !isNaN(h) && l > 0 && wi > 0 && h > 0;

      if (hasDimensions) {
        if (service === 'EMS') {
          // EMS uses divisor 6000
          volWeight = (l * wi * h) / 6000;
        } else {
          // ECMS uses divisor 5000
          volWeight = (l * wi * h) / 5000;
        }

        // Берем больший вес из фактического и объемного
        finalWeight = Math.max(actualWeight, volWeight);
        setVolumetricWeight(volWeight);
      } else {
        setVolumetricWeight(null);
      }

      // Округляем вес до 0.5 кг для тарификации (как в EMS/ECMS)
      // Например: 0.4кг -> 0.5кг, 0.6кг -> 1.0кг, 1.2кг -> 1.5кг
      const chargeableWeightRounded = Math.ceil(finalWeight * 2) / 2;
      setChargeableWeight(chargeableWeightRounded);

      // Calculate cost based on rounded weight
      const cost = service === 'EMS'
        ? calculateEMSCost(chargeableWeightRounded, emsZone)
        : calculateECMSCost(chargeableWeightRounded, ecmsDestination);

      setShippingCost(cost);

      // Обновляем ключ для принудительного ререндера результатов
      setCalculationKey(prev => prev + 1);
    }, 10);
  };


  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl flex items-center justify-center">
          <Calculator className="text-white" size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">International Shipping Calculator</h2>
          <p className="text-sm text-gray-500">Calculate shipping costs from Japan</p>
        </div>
      </div>

      {/* Service Toggle */}
      <div className="mb-6">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
          <Plane size={16} />
          Shipping Service
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setService('EMS')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all ${
              service === 'EMS'
                ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Package size={18} />
            Japan Post EMS
          </button>
          <button
            onClick={() => setService('ECMS')}
            className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all ${
              service === 'ECMS'
                ? 'bg-gradient-to-r from-green-600 to-green-700 text-white shadow-md'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <Plane size={18} />
            FedEx
          </button>
        </div>
        {service === 'EMS' && (
          <div className="flex items-center gap-2 text-xs text-amber-700 mt-2 font-semibold bg-amber-50 px-3 py-2 rounded-lg">
            <svg className="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            EMS to USA is currently suspended
          </div>
        )}
        {service === 'ECMS' && (
          <div className="flex items-center gap-2 text-xs text-green-700 mt-2 font-semibold bg-green-50 px-3 py-2 rounded-lg">
            <svg className="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            FedEx available worldwide including USA
          </div>
        )}
      </div>

      {/* Destination Selection */}
      <div className="mb-6">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
          <MapPin size={16} />
          Destination
        </label>

        {service === 'EMS' ? (
          // EMS Zone Dropdown Selector
          <div className="relative" ref={emsDropdownRef}>
            <button
              onClick={() => setEmsDropdownOpen(!emsDropdownOpen)}
              className="w-full p-4 rounded-xl text-left transition-all border-2 border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-100">
                  <MapPin size={18} className="text-blue-600" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">
                    {emsZones.find(z => z.zone === emsZone)?.name}
                  </p>
                  <p className="text-xs text-gray-600">
                    {emsZones.find(z => z.zone === emsZone)?.desc}
                  </p>
                </div>
              </div>
              <ChevronDown
                size={20}
                className={`text-gray-500 transition-transform ${emsDropdownOpen ? 'rotate-180' : ''}`}
              />
            </button>

            {/* Dropdown Menu */}
            {emsDropdownOpen && (
              <div className="absolute z-50 w-full mt-2 bg-white border-2 border-gray-200 rounded-xl shadow-lg overflow-hidden">
                {emsZones.map((z) => (
                  <button
                    key={z.zone}
                    onClick={() => {
                      setEmsZone(z.zone as 1 | 2 | 3 | 5);
                      setEmsDropdownOpen(false);
                    }}
                    className={`w-full p-4 text-left transition-all hover:bg-blue-50 border-b border-gray-100 last:border-b-0 ${
                      emsZone === z.zone ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${
                        emsZone === z.zone ? 'bg-blue-100' : 'bg-gray-100'
                      }`}>
                        <MapPin size={18} className={emsZone === z.zone ? 'text-blue-600' : 'text-gray-600'} />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{z.name}</p>
                        <p className="text-xs text-gray-600">{z.desc}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          // FedEx Destination - Fixed USA only
          <div className="w-full p-4 rounded-xl border-2 border-green-200 bg-green-50 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-100">
              <MapPin size={18} className="text-green-600" />
            </div>
            <div>
              <p className="font-bold text-gray-900">United States</p>
              <p className="text-xs text-gray-600">Available worldwide - USA shown as example</p>
            </div>
          </div>
        )}
      </div>

      {/* Weight - Only show for EMS */}
      {service === 'EMS' && (
        <div className="mb-6">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
            <Weight size={16} />
            Actual Weight (grams)
          </label>
          <input
            type="number"
            step="1"
            min="0"
            placeholder="e.g., 500 or 2500"
            value={weightGrams}
            onChange={(e) => setWeightGrams(e.target.value)}
            className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
          />
          <p className="text-xs text-gray-500 mt-1">
            Enter weight in grams (e.g., 400g = 400, 1.5kg = 1500)
          </p>
        </div>
      )}

      {/* Dimensions - Only show for EMS */}
      {service === 'EMS' && (
        <div className="mb-6">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
          <Ruler size={16} />
          Parcel Dimensions (cm) - Optional
        </label>
        <div className="grid grid-cols-3 gap-3">
          <input
            type="number"
            step="1"
            min="0"
            placeholder="Length"
            value={length}
            onChange={(e) => setLength(e.target.value)}
            className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
          />
          <input
            type="number"
            step="1"
            min="0"
            placeholder="Width"
            value={width}
            onChange={(e) => setWidth(e.target.value)}
            className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
          />
          <input
            type="number"
            step="1"
            min="0"
            placeholder="Height"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
          />
        </div>
        <div className="flex items-start gap-2 text-xs text-gray-500 mt-2 bg-gray-50 p-3 rounded-lg">
          <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          <div>
            <p>If dimensions are provided, volumetric weight will be calculated (L × W × H ÷ {service === 'EMS' ? '6000' : '5000'}).</p>
            <p className="mt-1 font-semibold text-orange-600">
              You'll be charged for whichever is greater: actual or volumetric weight.
            </p>
          </div>
        </div>
      </div>
      )}

      {/* Additional Services - Only show for EMS */}
      {service === 'EMS' && (
        <div className="mb-6">
        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
          <Layers size={16} />
          Additional Services (Optional)
        </label>
        <div className="space-y-3">
          {/* Photo Service */}
          <button
            onClick={() => setPhotoService(!photoService)}
            className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
              photoService
                ? 'border-purple-500 bg-purple-50 shadow-md'
                : 'border-gray-200 bg-white hover:border-purple-300 hover:bg-purple-50'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg mt-0.5 ${
                photoService ? 'bg-purple-100' : 'bg-gray-100'
              }`}>
                <Camera size={18} className={photoService ? 'text-purple-600' : 'text-gray-600'} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-gray-900">Photo Service</span>
                  <span className="text-sm font-bold text-gray-900">¥500</span>
                </div>
                <p className="text-xs text-gray-600">
                  Receive up to 3 photos of your items before shipping for quality inspection
                </p>
              </div>
            </div>
          </button>

          {/* Consolidation */}
          <button
            onClick={() => setConsolidation(!consolidation)}
            className={`w-full p-4 rounded-xl text-left transition-all border-2 ${
              consolidation
                ? 'border-blue-500 bg-blue-50 shadow-md'
                : 'border-gray-200 bg-white hover:border-blue-300 hover:bg-blue-50'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg mt-0.5 ${
                consolidation ? 'bg-blue-100' : 'bg-gray-100'
              }`}>
                <Package2 size={18} className={consolidation ? 'text-blue-600' : 'text-gray-600'} />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-gray-900">Package Consolidation</span>
                  <span className="text-sm font-bold text-green-600">Free</span>
                </div>
                <p className="text-xs text-gray-600">
                  Combine multiple packages into one to save on shipping costs
                </p>
              </div>
            </div>
          </button>
        </div>

        <div className="flex items-start gap-2 text-xs text-blue-700 mt-3 bg-blue-50 p-3 rounded-lg">
          <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
          </svg>
          <p>
            These services are applied after your items arrive at our warehouse in Japan. The calculator shows estimated costs for planning purposes.
          </p>
        </div>
      </div>
      )}

      {/* Calculate Button - Only show for EMS */}
      {service === 'EMS' && (
        <div className="mb-6">
          <button
            onClick={handleCalculate}
            className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold py-4 rounded-xl hover:from-blue-700 hover:to-blue-800 transition-all shadow-md hover:shadow-lg hover:scale-105 active:scale-95"
          >
            Calculate Shipping Cost
          </button>
        </div>
      )}

      {/* FedEx Real-Time Calculator */}
      {service === 'ECMS' && (
        <div className="mb-6 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Plane className="text-green-600" size={20} />
            </div>
            <h3 className="font-bold text-gray-900">Get Real-Time FedEx Rates</h3>
          </div>
          <p className="text-sm text-gray-700 mb-4">
            For accurate FedEx International Priority rates, use the official FedEx Rate Calculator:
          </p>

          <div className="bg-white rounded-lg p-4 mb-4 border border-green-200">
            <p className="text-xs font-semibold text-gray-700 mb-2">📝 Quick Setup Instructions:</p>
            <ol className="text-xs text-gray-600 space-y-2 ml-4">
              <li className="flex gap-2">
                <span className="font-bold text-green-600">1.</span>
                <span><strong>Origin Country/territory:</strong> Select <strong className="text-green-700">Japan</strong></span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-green-600">2.</span>
                <span><strong>Origin postal code:</strong> Enter <code className="bg-gray-100 px-2 py-0.5 rounded">300-0837</code></span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-green-600">3.</span>
                <span><strong>Destination:</strong> Enter your country and postal code</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold text-green-600">4.</span>
                <span><strong>Package details:</strong> Enter weight and dimensions</span>
              </li>
            </ol>
          </div>

          <a
            href="https://www.fedex.com/en-us/online/rating.html#"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full bg-gradient-to-r from-green-600 to-green-700 text-white font-semibold py-4 rounded-xl hover:from-green-700 hover:to-green-800 transition-all shadow-md hover:shadow-lg"
          >
            <Plane size={20} />
            Calculate on FedEx.com
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
            </svg>
          </a>

          <p className="text-xs text-gray-500 text-center mt-3">
            Opens in a new tab • Official FedEx calculator with live rates
          </p>
        </div>
      )}

      {/* Results - Only show for EMS */}
      {service === 'EMS' && shippingCost !== null && (
        <div key={calculationKey} className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Package className="text-blue-600" size={20} />
            <h3 className="text-lg font-bold text-gray-900">Shipping Estimate</h3>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Actual Weight:</span>
              <span className="font-semibold text-gray-900">
                {Math.round(parseFloat(weightGrams))}g ({(parseFloat(weightGrams) / 1000).toFixed(2)} kg)
              </span>
            </div>

            {volumetricWeight !== null && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Volumetric Weight:</span>
                <span className={`font-semibold ${volumetricWeight > (parseFloat(weightGrams) / 1000) ? 'text-orange-600' : 'text-gray-900'}`}>
                  {Math.round(volumetricWeight * 1000)}g ({volumetricWeight.toFixed(2)} kg)
                  {volumetricWeight > (parseFloat(weightGrams) / 1000) && (
                    <svg className="w-3 h-3 inline ml-1" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  )}
                </span>
              </div>
            )}

            <div className="border-t-2 border-blue-200 pt-3 mt-3 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-700">{service} Shipping:</span>
                <span className="font-semibold text-gray-900">{formatPrice(shippingCost)}</span>
              </div>

              {/* Additional Services Costs */}
              {(photoService || consolidation) && (
                <div className="space-y-2 pt-2 border-t border-blue-100">
                  {photoService && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600 flex items-center gap-2">
                        <Camera size={14} className="text-purple-600" />
                        Photo Service
                      </span>
                      <span className="font-semibold text-gray-900">¥500</span>
                    </div>
                  )}
                  {consolidation && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-600 flex items-center gap-2">
                        <Package2 size={14} className="text-blue-600" />
                        Consolidation
                      </span>
                      <span className="font-semibold text-green-600">Free</span>
                    </div>
                  )}
                </div>
              )}

              {/* Total */}
              <div className="flex justify-between items-center pt-3 border-t-2 border-blue-200">
                <span className="text-lg font-bold text-gray-900">Total Estimated Cost:</span>
                <span className={`text-2xl font-bold ${service === 'EMS' ? 'text-blue-600' : 'text-green-600'}`}>
                  {formatPrice(shippingCost + (photoService ? 500 : 0))}
                </span>
              </div>
            </div>

            <div className={`flex items-start gap-2 border rounded-lg p-3 mt-4 ${service === 'EMS' ? 'bg-blue-100 border-blue-300' : 'bg-green-100 border-green-300'}`}>
              <svg className={`w-4 h-4 flex-shrink-0 mt-0.5 ${service === 'EMS' ? 'text-blue-600' : 'text-green-600'}`} fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
              <div>
                <p className={`text-xs ${service === 'EMS' ? 'text-blue-800' : 'text-green-800'}`}>
                  This is an estimate based on {service === 'EMS' ? 'Japan Post EMS' : 'FedEx International Priority'} rates. Actual costs may vary.
                  {volumetricWeight !== null && volumetricWeight > (parseFloat(weightGrams) / 1000) && (
                    <span className="block mt-2 font-semibold text-orange-700 flex items-start gap-1">
                      <svg className="w-3 h-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      Your package is charged by volumetric weight because it's larger than actual weight.
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
