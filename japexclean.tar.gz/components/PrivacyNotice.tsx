// components/PrivacyNotice.tsx
'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { usePathname } from 'next/navigation';

export default function PrivacyNotice() {
  const [show, setShow] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    // Показываем уведомление только на главной странице и если пользователь еще не видел
    if (pathname === '/' && !localStorage.getItem('privacyNoticeSeen')) {
      setShow(true);
    }
  }, [pathname]);

  const handleClose = () => {
    setShow(false);
    localStorage.setItem('privacyNoticeSeen', 'true'); // пометим, что пользователь закрыл
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 flex items-center justify-center z-50 bg-black/50 p-4"
        >
          <div className="bg-white rounded-2xl shadow-xl p-6 max-w-lg w-full text-center relative">
            <h2 className="text-xl font-bold mb-3">Privacy & Cookies Notice</h2>
            <p className="text-gray-700 text-sm mb-4">
              We collect information such as your name, email, and browsing data to improve your experience.
              We also use cookies to provide better functionality and analytics.
            </p>
            <button
              onClick={handleClose}
              className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 font-bold"
            >
              ✕
            </button>
            <button
              onClick={handleClose}
              className="mt-2 bg-blue-500 text-white px-5 py-2 rounded-full hover:bg-blue-600 font-semibold"
            >
              Close
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
