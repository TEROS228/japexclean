"use client";

import React, { useState, useRef, useEffect, Fragment } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ShoppingCart, User, Search } from "lucide-react";
import { Menu, Transition } from "@headlessui/react";
import {
  isAuthenticated,
  getUserData,
  clearAuthData
} from "@/lib/auth";
import { useMarketplace } from "@/context/MarketplaceContext";
import { useCart } from "@/context/CartContext";
import { yahooCategories, YahooCategory } from "@/data/yahoo-categories";
import SignUpModal from "./SignUpModal";
import LoginModal from "./LoginModal";
import UserInfoModal from "./UserInfoModal";
import ClientOnly from "./ClientOnly";
import CurrencySelector from "./CurrencySelector";
import LanguageSelector from "./LanguageSelector";

interface Category {
  id: number;
  name: string;
  subcategories?: Category[];
}

export default function Header({ categories, onCategoryMenuRequest }: { categories?: Category[], onCategoryMenuRequest?: () => void }) {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  const { marketplace, setMarketplace } = useMarketplace();
  const { cart } = useCart();
  const [categoryDropdownOpen, setCategoryDropdownOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [hoveredCategory, setHoveredCategory] = useState<number | null>(null);

  // Функция переключения маркетплейса с редиректом на главную
  const handleMarketplaceChange = (newMarketplace: 'rakuten' | 'yahoo') => {
    if (marketplace === newMarketplace) return;

    // Проверяем текущий путь
    const currentPath = window.location.pathname;
    const isHomePage = currentPath === '/';
    const isCartPage = currentPath === '/cart';

    // Если на главной или в корзине, просто меняем маркетплейс
    if (isHomePage || isCartPage) {
      setMarketplace(newMarketplace);
      return;
    }

    // Для остальных страниц - переходим на главную, затем меняем маркетплейс
    router.push('/');
    setTimeout(() => {
      setMarketplace(newMarketplace);
    }, 100);
  };

  // Выбираем категории в зависимости от маркетплейса
  const displayCategories = marketplace === "yahoo"
    ? yahooCategories.map(cat => ({
        id: cat.id,
        name: cat.name,
        subcategories: cat.subcategories?.map(sub => ({
          id: sub.id,
          name: sub.name
        }))
      }))
    : categories;

  // Debug: логируем подкатегории
  useEffect(() => {
    if (marketplace === "yahoo" && displayCategories) {
      const withSubcats = displayCategories.filter(c => c.subcategories && c.subcategories.length > 0);
      console.log(`[Header] Yahoo categories loaded: ${displayCategories.length}, with subcategories: ${withSubcats.length}`);
      if (withSubcats.length > 0) {
        console.log(`[Header] First category with subcategories: ${withSubcats[0].name}, subcategories: ${withSubcats[0].subcategories?.length}`);
      }
    }
  }, [marketplace, displayCategories]);

  const [searchTerm, setSearchTerm] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Модалки
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);

  // Получаем данные пользователя ТОЛЬКО после mount
  const [user, setUser] = useState<any>(null);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    setMounted(true);

    setUser(getUserData());
    setAuthenticated(isAuthenticated());

    const handleBalanceUpdate = () => {
      setUser(getUserData());
    };

    window.addEventListener('balanceUpdated', handleBalanceUpdate);

    // Check for category menu flag
    const checkInterval = setInterval(() => {
      const shouldOpen = sessionStorage.getItem('openCategoryMenu');
      if (shouldOpen === 'true') {
        sessionStorage.removeItem('openCategoryMenu');
        setCategoryDropdownOpen(true);
      }
    }, 100);

    return () => {
      window.removeEventListener('balanceUpdated', handleBalanceUpdate);
      clearInterval(checkInterval);
    };
  }, []);

  useEffect(() => {
    function onClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setCategoryDropdownOpen(false);
      }
    }
    if (categoryDropdownOpen) {
      document.addEventListener("mousedown", onClickOutside);
    }
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, [categoryDropdownOpen]);

  // Сбрасываем выбранную категорию при смене маркетплейса
  useEffect(() => {
    setSelectedCategory(null);
  }, [marketplace]);

  const onSelectCategory = (cat: Category) => {
    setSelectedCategory(cat);
    setCategoryDropdownOpen(false);
    router.push(`/category/${cat.id}`);
  };

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      router.push(`/search?query=${encodeURIComponent(searchTerm.trim())}`);
      setSearchTerm("");
      searchInputRef.current?.blur();
    }
  };

  const handleLogout = () => {
    clearAuthData();
    window.location.href = window.location.href;
  };

  if (!mounted) {
    return (
      <>
        <header className="bg-white border-b border-gray-200/50 shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <Image
                src="/logo.jpg"
                alt="Japrix"
                width={200}
                height={67}
                className="object-contain h-[67px] w-auto"
              />
              <div className="flex gap-3">
                <div className="w-11 h-11 rounded-xl border-2 border-gray-200 flex items-center justify-center bg-white shadow-sm">
                  <ShoppingCart size={22} className="text-gray-400" />
                </div>
                <div className="w-11 h-11 rounded-xl border-2 border-gray-200 flex items-center justify-center bg-white shadow-sm">
                  <User size={22} className="text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </header>
      </>
    );
  }

  return (
    <>
      <header className="bg-white border-b border-gray-200/50 shadow-lg transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          {/* Top Row */}
          <div className="flex items-center justify-between gap-4 mb-4">
            <div
              className="cursor-pointer group"
              onClick={() => router.push("/")}
            >
              <Image
                src="/logo.jpg"
                alt="Japrix"
                width={200}
                height={67}
                className="object-contain transition-all group-hover:scale-105 h-[67px] w-auto"
              />
            </div>

            {/* Marketplace Switcher */}
            <div className="relative inline-flex items-center gap-0 p-0.5 bg-white rounded-full border-2 border-gray-200 shadow-sm">
              {/* Sliding background indicator */}
              <div
                className={`absolute top-0.5 bottom-0.5 w-[calc(50%-2px)] bg-gradient-to-br rounded-full transition-all duration-300 ease-out shadow-md ${
                  marketplace === "rakuten"
                    ? "left-0.5 from-green-500 to-emerald-600"
                    : "left-[calc(50%+0px)] from-red-500 to-red-600"
                }`}
              />

              <button
                onClick={() => handleMarketplaceChange("rakuten")}
                className={`relative z-10 px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                  marketplace === "rakuten"
                    ? "text-white"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                  </svg>
                  Rakuten
                </span>
              </button>

              <button
                onClick={() => handleMarketplaceChange("yahoo")}
                className={`relative z-10 px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                  marketplace === "yahoo"
                    ? "text-white"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <span className="flex items-center gap-1.5">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                  Yahoo
                </span>
              </button>
            </div>

            <div className="flex items-center gap-2.5">
              <CurrencySelector />
              <LanguageSelector />

              <Link href="/cart">
                <div className="group relative w-11 h-11 rounded-full border-2 border-gray-200 flex items-center justify-center bg-white hover:border-green-500 hover:bg-green-50 transition-all cursor-pointer hover:scale-110 active:scale-95 shadow-sm hover:shadow-md">
                  <ShoppingCart size={20} className="text-gray-600 group-hover:text-green-600 transition-colors" />
                  {cart.length > 0 && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-lg">
                      {cart.length}
                    </div>
                  )}
                </div>
              </Link>

              <Menu as="div" className="relative">
                <Menu.Button className="group w-11 h-11 rounded-full border-2 border-gray-200 flex items-center justify-center bg-white hover:border-green-500 hover:bg-green-50 transition-all cursor-pointer hover:scale-110 active:scale-95 shadow-sm hover:shadow-md">
                  <User size={20} className="text-gray-600 group-hover:text-green-600 transition-colors" />
                </Menu.Button>
                <Transition
                  as={Fragment}
                  enter="transition ease-out duration-200"
                  enterFrom="opacity-0 scale-95"
                  enterTo="opacity-100 scale-100"
                  leave="transition ease-in duration-150"
                  leaveFrom="opacity-100 scale-100"
                  leaveTo="opacity-0 scale-95"
                >
                  <Menu.Items className="absolute right-0 mt-2 w-44 bg-white border-2 border-gray-100 rounded-2xl shadow-2xl z-10 overflow-hidden">
                    <div className="py-1">
                      {authenticated ? (
                        <>
                          <Menu.Item>
                            {({ active }) => (
                              <Link
                                href="/profile"
                                className={`block w-full text-left px-4 py-3 text-sm font-medium transition-colors ${
                                  active ? "bg-green-50 text-green-700" : "text-gray-700"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                  </svg>
                                  My Profile
                                </div>
                              </Link>
                            )}
                          </Menu.Item>
                          <div className="border-t border-gray-100"></div>
                          <Menu.Item>
                            {({ active }) => (
                              <button
                                onClick={handleLogout}
                                className={`w-full text-left px-4 py-3 text-sm font-medium transition-colors ${
                                  active ? "bg-red-50 text-red-600" : "text-red-500"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                  </svg>
                                  Log out
                                </div>
                              </button>
                            )}
                          </Menu.Item>
                        </>
                      ) : (
                        <>
                          <Menu.Item>
                            {({ active }) => (
                              <button
                                onClick={() => setIsLoginOpen(true)}
                                className={`w-full text-left px-4 py-3 text-sm font-medium transition-colors ${
                                  active ? "bg-green-50 text-green-700" : "text-gray-700"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                                  </svg>
                                  Log In
                                </div>
                              </button>
                            )}
                          </Menu.Item>
                          <Menu.Item>
                            {({ active }) => (
                              <button
                                onClick={() => setIsSignUpOpen(true)}
                                className={`w-full text-left px-4 py-3 text-sm font-medium transition-colors ${
                                  active ? "bg-green-50 text-green-700" : "text-gray-700"
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                                  </svg>
                                  Sign Up
                                </div>
                              </button>
                            )}
                          </Menu.Item>
                        </>
                      )}
                    </div>
                  </Menu.Items>
                </Transition>
              </Menu>
            </div>
          </div>

          {/* Bottom Row - Search */}
          <div className="flex gap-3 items-center">
            {/* Category selector */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setCategoryDropdownOpen(!categoryDropdownOpen)}
                className="group relative overflow-hidden px-5 py-3 rounded-full border-2 border-gray-200 bg-white text-gray-700 font-bold hover:border-green-500 hover:bg-green-50 transition-all hover:scale-105 active:scale-95 flex items-center gap-2.5 whitespace-nowrap shadow-sm hover:shadow-md"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-green-600/0 via-green-600/5 to-green-600/0 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <svg className="w-5 h-5 text-gray-500 group-hover:text-green-600 transition-colors relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                <span className="relative z-10">{selectedCategory ? selectedCategory.name : "Categories"}</span>
                <svg
                  className={`w-4 h-4 transition-all duration-300 relative z-10 group-hover:text-green-600 ${
                    categoryDropdownOpen ? "rotate-180" : ""
                  }`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {categoryDropdownOpen && (
                <div className="absolute mt-2 w-64 max-h-96 overflow-auto bg-white border-2 border-gray-100 rounded-2xl shadow-2xl z-50 animate-scaleIn">
                  {displayCategories && displayCategories.length > 0 ? (
                    displayCategories.map((cat) => (
                      <div key={cat.id} className="relative group">
                        <button
                          onClick={() => onSelectCategory(cat)}
                          onMouseEnter={() => setHoveredCategory(cat.id)}
                          onMouseLeave={() => setHoveredCategory(null)}
                          className={`block w-full text-left px-5 py-3 text-sm font-medium transition-colors border-b border-gray-100 last:border-0 flex items-center justify-between ${
                            marketplace === "yahoo"
                              ? "text-gray-700 hover:bg-red-50 hover:text-red-700"
                              : "text-gray-700 hover:bg-green-50 hover:text-green-700"
                          }`}
                        >
                          <span className="flex-1">{cat.name}</span>
                          {cat.subcategories && cat.subcategories.length > 0 && (
                            <span className="flex items-center gap-1 text-xs text-gray-500">
                              <span>{cat.subcategories.length}</span>
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                              </svg>
                            </span>
                          )}
                        </button>

                        {/* Подкатегории */}
                        {hoveredCategory === cat.id &&
                         cat.subcategories &&
                         cat.subcategories.length > 0 && (
                          <div
                            className="absolute left-full top-0 ml-1 w-72 max-h-96 overflow-auto bg-white border-2 border-gray-100 rounded-2xl shadow-2xl"
                            style={{ zIndex: 9999 }}
                            onMouseEnter={() => setHoveredCategory(cat.id)}
                            onMouseLeave={() => setHoveredCategory(null)}
                          >
                            {cat.subcategories.map((subcat) => (
                              <button
                                key={subcat.id}
                                onClick={() => {
                                  onSelectCategory(subcat);
                                  setHoveredCategory(null);
                                }}
                                className={`block w-full text-left px-4 py-2 text-xs font-medium transition-colors border-b border-gray-50 last:border-0 ${
                                  marketplace === "yahoo"
                                    ? "text-gray-600 hover:bg-red-50 hover:text-red-700"
                                    : "text-gray-600 hover:bg-green-50 hover:text-green-700"
                                }`}
                              >
                                {subcat.name}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="p-5 text-gray-500 text-sm text-center">No categories</div>
                  )}
                </div>
              )}
            </div>

            {/* Search box */}
            <div className="flex-1">
              <form
                onSubmit={onSearchSubmit}
                className="relative group w-full"
              >
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder={marketplace === "yahoo" ? "Search products or paste Yahoo URL..." : "Search products or paste Rakuten URL..."}
                  className="w-full rounded-full border-2 border-gray-200 bg-white pl-12 pr-28 text-sm font-medium text-gray-900 placeholder-gray-400 focus:border-green-500 focus:ring-4 focus:ring-green-500/10 focus:outline-none transition-all shadow-sm focus:shadow-md"
                  style={{ height: '48px', lineHeight: '48px', paddingTop: '0', paddingBottom: '0' }}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                  <Search size={19} className="text-gray-400 group-focus-within:text-green-600 transition-colors" />
                </div>
                <button
                  type="submit"
                  className="shimmer bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold text-sm rounded-full hover:from-green-700 hover:to-emerald-700 transition-all hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
                  style={{ position: 'absolute', right: '6px', top: '50%', transform: 'translateY(-50%)', padding: '8px 20px', height: 'auto' }}
                >
                  Search
                </button>
              </form>
            </div>
          </div>
        </div>
      </header>

      {/* Модальные окна */}
      <ClientOnly>
        <SignUpModal
          isOpen={isSignUpOpen}
          onClose={() => setIsSignUpOpen(false)}
          onSwitchToLogin={() => {
            setIsSignUpOpen(false);
            setIsLoginOpen(true);
          }}
        />
        <LoginModal
          isOpen={isLoginOpen}
          onClose={() => setIsLoginOpen(false)}
          onSwitchToSignUp={() => {
            setIsLoginOpen(false);
            setIsSignUpOpen(true);
          }}
        />
        {isInfoOpen && <UserInfoModal onClose={() => setIsInfoOpen(false)} />}
      </ClientOnly>

      <style jsx>{`
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-scaleIn {
          animation: scaleIn 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
      `}</style>
    </>
  );
}
